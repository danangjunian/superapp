import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Primary app colors used throughout the UI. These values have been tuned
/// for better accessibility and contrast. Darker greens provide enough
/// contrast against light backgrounds, while the background and outline
/// colors remain soft to reduce eye strain.
const Color kPrimaryGreen = Color(0xFF006A4E);      // Main brand color (dark teal green)
const Color kPrimaryGreenDark = Color(0xFF004D39); // Shade for gradients and dark contexts
const Color kSurfaceWhite = Color(0xFFFFFFFF);      // Pure white for cards and surfaces
const Color kSoftMint = Color(0xFFF3F8F5);         // Light mint background to soften the UI
const Color kOutline = Color(0xFFB4D1C8);          // Subtle outline/border color
const Color kAccentGreen = Color(0xFF25A67E);      // Secondary accent color for chips/buttons

/// Builds the global theme for the application.
ThemeData buildAppTheme() {
  final base = ThemeData(useMaterial3: true);
  // Build an explicit color scheme to ensure all contrast pairs are defined.
  final colorScheme = ColorScheme(
    brightness: Brightness.light,
    primary: kPrimaryGreen,
    onPrimary: Colors.white,
    secondary: kAccentGreen,
    onSecondary: Colors.white,
    surface: kSurfaceWhite,
    onSurface: const Color(0xFF1F2E25),
    background: kSoftMint,
    onBackground: const Color(0xFF1F2E25),
    error: Colors.red,
    onError: Colors.white,
    primaryContainer: kPrimaryGreenDark,
    onPrimaryContainer: Colors.white,
    secondaryContainer: kAccentGreen.withOpacity(0.15),
    onSecondaryContainer: const Color(0xFF1F2E25),
  );
  // Create a text theme based on Inter with explicit colors for contrast. All
  // text defaults to a dark, high‑contrast color defined in the color scheme.
  final textTheme = GoogleFonts.interTextTheme(base.textTheme)
      .apply(bodyColor: colorScheme.onBackground, displayColor: colorScheme.onBackground)
      .copyWith(
    headlineLarge: GoogleFonts.inter(
      fontSize: 28,
      fontWeight: FontWeight.w700,
      letterSpacing: -0.2,
      color: colorScheme.onBackground,
    ),
    titleLarge: GoogleFonts.inter(
      fontSize: 20,
      fontWeight: FontWeight.w600,
      color: colorScheme.onBackground,
    ),
    bodyLarge: GoogleFonts.inter(
      fontSize: 16,
      height: 1.5,
      color: colorScheme.onBackground,
    ),
    bodyMedium: GoogleFonts.inter(
      fontSize: 14,
      height: 1.5,
      color: colorScheme.onBackground,
    ),
  );
  return base.copyWith(
    colorScheme: colorScheme,
    scaffoldBackgroundColor: colorScheme.background,
    textTheme: textTheme,
    appBarTheme: AppBarTheme(
      elevation: 0,
      backgroundColor: colorScheme.background,
      foregroundColor: colorScheme.onBackground,
      centerTitle: true,
      titleTextStyle: textTheme.titleLarge,
    ),
    cardTheme: CardTheme(
      elevation: 0,
      color: colorScheme.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      margin: const EdgeInsets.all(12),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.white,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide(color: kOutline),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide(color: kOutline),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide(color: kPrimaryGreen, width: 2),
      ),
      hintStyle: TextStyle(color: colorScheme.onBackground.withOpacity(0.6)),
      labelStyle: TextStyle(color: colorScheme.onBackground),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: kPrimaryGreen,
        foregroundColor: Colors.white,
        elevation: 0,
        minimumSize: const Size.fromHeight(50),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
      ),
    ),
    chipTheme: base.chipTheme.copyWith(
      backgroundColor: kAccentGreen.withOpacity(0.1),
      selectedColor: kAccentGreen.withOpacity(0.3),
      labelStyle: TextStyle(
        fontWeight: FontWeight.w600,
        color: colorScheme.onBackground,
      ),
      shape: StadiumBorder(side: BorderSide(color: kOutline)),
    ),
    dividerTheme: DividerThemeData(
      color: kOutline.withOpacity(0.5),
      thickness: 1,
    ),
  );
}